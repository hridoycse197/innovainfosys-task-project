package com.example.ghfw61_hidexaxisvalue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
